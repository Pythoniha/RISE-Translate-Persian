<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* language locale */
$lang["language_locale"] = "fa"; //locale code
$lang["language_locale_long"] = "fa_IR"; //long locale code

/* common */
$lang["add"] = "اضافه کردن";
$lang["edit"] = "اصلاح";
$lang["close"] = "بستن";
$lang["cancel"] = "کنسل";
$lang["save"] = "ذخیره";
$lang["delete"] = "حذف کردن";
$lang["description"] = "Description";
$lang["admin"] = "آدمین";
$lang["manager"] = "مدیر";
$lang["options"] = "تنضیمات";
$lang["id"] = "آیدی";
$lang["name"] = "نام";
$lang["email"] = "ایمیل";
$lang["username"] = "نام کاربری";
$lang["password"] = "رمز ورود";
$lang["retype_password"] = "تکرار دوباره";
$lang["previous"] = "قبلی";
$lang["next"] = "بعدی";
$lang["active"] = "قعال کردن";
$lang["inactive"] = "غیر فعال کردن";
$lang["status"] = "وضعیت";
$lang["start_date"] = "تاریخ شروع";
$lang["end_date"] = "تاریخ پایان";
$lang["start_time"] = "تاریخ شروع";
$lang["end_time"] = "تاریخ پایان";
$lang["deadline"] = "تاریخ سر رسید";
$lang["added"] = "اضافه";
$lang["created_date"] = "تاریخ ساخت";
$lang["created"] = "ساخت";
$lang["created_by"] = "ساخته شده توسط";
$lang["updated"] = "به روز رسانی";
$lang["deleted"] = "حذف شده";
$lang["currency"] = "واحد پول";
$lang["new"] = "جدید";
$lang["open"] = "بازکردن";
$lang["closed"] = "بستن";
$lang["date"] = "روز";
$lang["yes"] = "بله ؟";
$lang["no"] = "نه";
$lang["add_more"] = "اضافه کردن بیشتر";
$lang["crop"] = "محصول";
$lang["income"] = "درآمد";
$lang["income_vs_expenses"] = "درآمد در مقابل هزینه";

$lang["title"] = "عنوان";
$lang["reset"] = "بازنشانی";
$lang["share_with"] = "اشتراک گذاشتن با";
$lang["company_name"] = "نام شرکت";
$lang["address"] = "آدرس";
$lang["city"] = "شهر";
$lang["state"] = "استان";
$lang["zip"] = "کد پستی";
$lang["country"] = "کشور";
$lang["phone"] = "تلفن";
$lang["private"] = "خصوصی";
$lang["website"] = "وب سایت";

$lang["sunday"] = "یکشنبه";
$lang["monday"] = "دوشنبه";
$lang["tuesday"] = "سه شنبه";
$lang["wednesday"] = "چهارشنبه";
$lang["thursday"] = "پنجشنبه";
$lang["friday"] = "جمعه";
$lang["saturday"] = "شنبه";

$lang["daily"] = "روزانه";
$lang["monthly"] = "ماهانه";
$lang["weekly"] = "هفتگی";
$lang["yearly"] = "سالانه";

$lang["see_all"] = "دیدن همه";

/* messages */
$lang["error_occurred"] = "با عرض پوزش در هنگام پردازش مشکلی رخ داده است <br> لطفا بعدا امتحان کنید.";
$lang["field_required"] = "این قسمت الزامی است";
$lang["end_date_must_be_equal_or_greater_than_start_date"] = "تاریخ پایان باید بیشتر مساوی تاریخ شروع باشد";
$lang["date_must_be_equal_or_greater_than_today"] = "تاریخ باید بیشتر مساوی امروز باشد";
$lang["enter_valid_email"] = "لطفا یک آدرس ایمیل معتبر وارد کنید.";
$lang["enter_same_value"] = "لطفا همان مقدار را مجدادا وارد کنید.";
$lang["record_saved"] = "این رکورد ذخیره شد.";
$lang["record_updated"] = "این رکورد بروزرسانی شد.";
$lang["record_cannot_be_deleted"] = "این رکورد در حال استفاده است، شما نمیتوانید رکورد را حذف کنید.";
$lang["record_deleted"] = "رکورد حذف شد.";
$lang["record_undone"] = "رکورد لغو شد.";
$lang["settings_updated"] = "تنظیمات بروزرسانی شد.";
$lang["enter_minimum_6_characters"] = "لطفا حداقل 6 حرف وارد کنید.";
$lang["message_sent"] = "پیام ارسال شد.";
$lang["invalid_file_type"] = "فرمت فایل مجاز نیست.";
$lang["something_went_wrong"] = "اوه ، مشکلی پیش آمده!";
$lang["duplicate_email"] = "آدرس ایمیلی که وارد کردید در حال حاضر ثبت شده است.";
$lang["comment_submited"] = "نظر ارسال شد.";
$lang["no_new_messages"] = "شما پیغام جدیدی ندارید";
$lang["sent_you_a_message"] = "برای شما پیامی ارسال کرد";
$lang["max_file_size_3mb_message"] = "اندازه فایل نباید بیشتر از 3 مگابایت باشد.";
$lang["keep_it_blank_to_use_default"] = "برای استفاده از حالت پیش فرض این مقدار را خالی نگه دارید.";
$lang["admin_user_has_all_power"] = "کاربران مدیر اجازه دسترسی و تغییر هر چیزی را در این سیستم دارند!";
$lang["no_posts_to_show"] = "هیچ پستی برای نمایش وجود ندارد";

/* team_member */
$lang["add_team_member"] = "اضافه کردن عضو";
$lang["edit_team_member"] = "تغییر عضو تیم";
$lang["delete_team_member"] = "حذف عضو تیم";
$lang["team_member"] = "عضو تیم";
$lang["team_members"] = "اعضای تیم";
$lang["active_members"] = "اعضای فعال";
$lang["inactive_members"] = "اعضای غیرفعال";
$lang["first_name"] = "نام";
$lang["last_name"] = "نام خانوادگی";
$lang["mailing_address"] = "آدرس پستی";
$lang["alternative_address"] = "آدرس جایگزین";
$lang["phone"] = "شماره تلفن";
$lang["alternative_phone"] = "شماره تلفن جایگزین";
$lang["gender"] = "جنسیت";
$lang["male"] = "مذکر";
$lang["female"] = "مونت";
$lang["date_of_birth"] = "تاریخ تولد";
$lang["date_of_hire"] = "تاریخ استخدام";
$lang["ssn"] = "کد ملی";
$lang["salary"] = "حقوق";
$lang["salary_term"] = "مدت حقوق";
$lang["job_info"] = "اطلاعات شغلی";
$lang["job_title"] = "عنوان شغلی ";
$lang["general_info"] = "اطلاعات عمومی";
$lang["account_settings"] = "تنظیمات حساب";
$lang["list_view"] = "آخرین بازدید";
$lang["profile_image_changed"] = "تصویر پروفایل تغییر کرد.";
$lang["send_invitation"] = "ارسال دعوتنامه";
$lang["invitation_sent"] = "دعوت نامه ارسال شد.";
$lang["reset_info_send"] = "ایمیل ارسال شد!<br />لطفا ایمیل خود را برای راهنمایی بررسی کنید.";
$lang["profile"] = "پروفایل";
$lang["my_profile"] = "پروفایل من";
$lang["change_password"] = "عوض کردن رمز ورود";
$lang["social_links"] = "لینک های اجتماعی";
$lang["view_details"] = "مشاهده جزئیات";
$lang["invite_someone_to_join_as_a_team_member"] = "اسال دعوت برای ملحق شدن به تیم.";

/* team */
$lang["add_team"] = "افزودن تیم";
$lang["edit_team"] = "ویرایش تیم";
$lang["delete_teamn"] = "حذف تیم";
$lang["team"] = "تیم";
$lang["select_a_team"] = "انتخاب تیم";

/* dashboard */
$lang["dashboard"] = "داشبورد";

/* attendance */
$lang["add_attendance"] = "افزودن یک زمان به صورت دستی";
$lang["edit_attendance"] = "ویرایش کارت زمان";
$lang["delete_attendance"] = "حذف کارت زمان";
$lang["attendance"] = "کارت های زمان";
$lang["clock_in"] = "ساعت ورود";
$lang["clock_out"] = "ساعت خروج";
$lang["in_date"] = "تاریخ ورود";
$lang["out_date"] = "تاریخ خروج";
$lang["in_time"] = "زمان ورود";
$lang["out_time"] = "زمان خروج";
$lang["clock_started_at"] = "شروع از ساعت";
$lang["you_are_currently_clocked_out"] = "شما در حال حاضر خارج از ساعت کاری هستید";
$lang["members_clocked_in"] = "ساعت ورود اعضا";
$lang["members_clocked_out"] = "ساعت خروج اعضا";
$lang["my_time_cards"] = "کارت های زمانی من";
$lang["timecard_statistics"] = "آمار کارت های زمانی";
$lang["total_hours_worked"] = "مجموع ساعات کاری";
$lang["total_project_hours"] = "مجموع ساعات پروژه";

/* leave types */
$lang["add_leave_type"] = "افزودن نوع مرخصی";
$lang["edit_leave_type"] = "تغییر نوع مرخصی";
$lang["delete_leave_type"] = "حذف نوع مرخصی";
$lang["leave_type"] = "نوع مرخصی";
$lang["leave_types"] = "انواع مرخصی";

/* leave */
$lang["apply_leave"] = "درخواست مرخصی";
$lang["assign_leave"] = "تعیین مرخصی";
$lang["leaves"] = "مرخصی";
$lang["pending_approval"] = "در انتظار تایید";
$lang["all_applications"] = "همه برنامه ها";
$lang["duration"] = "مدت زمان";
$lang["single_day"] = "یک روزه";
$lang["mulitple_days"] = "چند روزه";
$lang["reason"] = "علت";
$lang["applicant"] = "درخواستت کننده";
$lang["approved"] = "تایید شده";
$lang["approve"] = "تایید";
$lang["rejected"] = "رد شده";
$lang["reject"] = "رد";
$lang["canceled"] = "کنسل شده";
$lang["completed"] = "تکمیل شده";
$lang["pending"] = "در انتظار";
$lang["day"] = "روز";
$lang["days"] = "روزها";
$lang["hour"] = "ساعت";
$lang["hours"] = "ساعات";
$lang["application_details"] = "جزئیات برنامه";
$lang["rejected_by"] = "رد شده توسط";
$lang["approved_by"] = "پذیرفته شده توسط";
$lang["start_date_to_end_date_format"] = "%s تا %s";
$lang["my_leave"] = "مرخصی من";

/* events */
$lang["add_event"] = "افزودن رویداد";
$lang["edit_event"] = "ویرایش رویداد";
$lang["delete_event"] = "حذف رویداد";
$lang["events"] = "رویداد ها";
$lang["event_calendar"] = "تقویم رویداد ها";
$lang["location"] = "محل";
$lang["event_details"] = "جزئیات رویداد";
$lang["event_deleted"] = "رویداد حذف شد.";
$lang["view_on_calendar"] = "مشاهده در تقویم";
$lang["no_event_found"] = "رویدادی یافت نشد!";
$lang["events_today"] = "رویدادهای امروز";

/* announcement */
$lang["add_announcement"] = "افزود اعلان";
$lang["edit_announcement"] = "ویرایش اعلان";
$lang["delete_announcement"] = "حذف اعلان";
$lang["announcement"] = "اعلان";
$lang["announcements"] = "اعلانات";
$lang["all_team_members"] = "تمامی اعضای تیم";
$lang["all_team_clients"] = "تمامی مشتری ها";

/* settings */
$lang["app_settings"] = "تنظیمات برنامه";
$lang["app_title"] = "عنوان برنامه";
$lang["site_logo"] = "لوگوی سایت";
$lang["invoice_logo"] = "لوگوی فاکتور";
$lang["timezone"] = "منطقه زمانی";
$lang["date_format"] = "فرمت تاریخ";
$lang["time_format"] = "فرمت زمان";
$lang["first_day_of_week"] = "اولین روز هفته";
$lang["currency_symbol"] = "نماد ارز";
$lang["general"] = "عمومی";
$lang["general_settings"] = "تنظیمات عمومی";
$lang["item_purchase_code"] = "کد خرید کالا";
$lang["company"] = "شرکت";
$lang["company_settings"] = "تنظیمات شرکت";
$lang["email_settings"] = "تنظیمات ایمیل";
$lang["payment_methods"] = "روش های پرداخت";
$lang["email_sent_from_address"] = "ارسال ایمیل از آدرس";
$lang["email_sent_from_name"] = "ارسال ایمیل از نام";
$lang["email_use_smtp"] = "استفاده از smtp";
$lang["email_smtp_host"] = "SMTP Host";
$lang["email_smtp_user"] = "SMTP User";
$lang["email_smtp_password"] = "SMPT Password";
$lang["email_smtp_port"] = "SMTP Port";
$lang["send_test_mail_to"] = "ارسال یک ایمیل تست به";
$lang["test_mail_sent"] = "ایمیل تست ارسال شد!";
$lang["test_mail_send_failed"] = "خطا هنگام ارسال ایمیل تست.";
$lang["settings"] = "تنظیمات";
$lang["updates"] = "بروزرسانی ها";
$lang["current_version"] = "نسخه فعلی";
$lang["language"] = "زبان";
$lang["ip_restriction"] = "محدودیت IP";
$lang["varification_failed_message"] = "با عرض پوزش کد خرید کالای شما تایید نشد.";
$lang["enter_one_ip_per_line"] = "در هر خط یک IP وارد کنید. اگر این قمست را خالی بگذارید تمامی کاربران مجاز هستند * کاربران مدیر تحت تاثییر قرار نمیگیرند.";
$lang["allow_timecard_access_from_these_ips_only"] = "دسترسی به کارت زمانی را فقط از طریق این IP ها مجاز کنید.";
$lang["decimal_separator"] = "جدا کننده اعشار";
$lang["client_settings"] = "تنظیمات کاربر";
$lang["disable_client_login_and_signup"] = "غیرفعال کردن ورود و ثبت نام کاربر";
$lang["disable_client_login_help_message"] = "تا زمانی که این گزینه فعال است کاربران قادر به ورود و ثبت نام در این سیستم نیستند.";
$lang["who_can_send_or_receive_message_to_or_from_clients"] = "چه کسی میتواند برای مشتری پیام بفرستد یا دریافت کند";

/* account */
$lang["authentication_failed"] = "احراز هویت انجام نشد!";
$lang["signin"] = "ورود";
$lang["sign_out"] = "خروج";
$lang["you_dont_have_an_account"] = "شما حساب کاربری ندارید؟";
$lang["already_have_an_account"] = "در حال حاضر حساب کاربری دارید؟";
$lang["forgot_password"] = "رمز ورود خود را فراموش کردید؟";
$lang["signup"] = "ثبت نام";
$lang["input_email_to_reset_password"] = "برای بازنشانی گذرواژه خود ، ایمیل خود را وارد کنید";
$lang["no_acount_found_with_this_email"] = "متأسفیم ، هیچ حسابی با این ایمیل پیدا نشد.";
$lang["reset_password"] = "بازنشانی رمز ورود";
$lang["password_reset_successfully"] = "رمز ورود شما با موفقیت تنظیم شد.";
$lang["account_created"] = "حساب کاربری شما با موفقیت ایجاد شد!";
$lang["invitation_expaired_message"] = "دعوتنامه منقضی شده است یا مشکلی پیش آمده است.";
$lang["account_already_exists_for_your_mail"] = "در حال حاضر حساب کاربری برای ایمیل شما وجود دارد.";
$lang["create_an_account_as_a_new_client"] = "ساخت حساب کاربری جدید به عنوان کاربر.";
$lang["create_an_account_as_a_team_member"] = "ساخت حساب کاربری به عنوان عضو تیم";
$lang["create_an_account_as_a_client_contact"] = "ساخت حساب کاربری  به عنوان مخاطب کاربر";

/* messages */
$lang["messages"] = "پیام ها";
$lang["message"] = "پیام";
$lang["compose"] = "ساخت";
$lang["send_message"] = "ارسال پیام";
$lang["write_a_message"] = "نوشتن یک پیام...";
$lang["reply_to_sender"] = "پاسخ به ارسال کننده...";
$lang["subject"] = "موضوع";
$lang["send"] = "ارسال";
$lang["to"] = "به";
$lang["from"] = "از طرف";
$lang["inbox"] = "صندوق ورودی";
$lang["sent_items"] = "ارسال کالاها";
$lang["me"] = "من";
$lang["select_a_message"] = "انتخاب یک پیام برای مشاهده";

/* clients */
$lang["add_client"] = "افزودن کاربر";
$lang["edit_client"] = "ویرایش کاربر";
$lang["delete_client"] = "حذف کاربر";
$lang["client"] = "کاربر";
$lang["clients"] = "کاربران";
$lang["client_details"] = "جزئیات کاربران";
$lang["due"] = "ناشی از";

$lang["add_contact"] = "افزودن مخاطب";
$lang["edit_contact"] = "ویرایش مخاطب";
$lang["delete_contact"] = "تغییر مخاطب";
$lang["contact"] = "مخاطب";
$lang["contacts"] = "مخاطبین";
$lang["users"] = "کاربران";
$lang["primary_contact"] = "ارتباط اولیه";
$lang["disable_login"] = "غیرفعال سازی ورود";
$lang["disable_login_help_message"] = "کاربر نمیتواند وارد این سیستم شود!";
$lang["email_login_details"] = "ارسال جزئیات ورود به سیستم برای این کاربر";
$lang["generate"] = "تولید";
$lang["show_text"] = "نمایش متن";
$lang["hide_text"] = "مخفی کردن متن";
$lang["mark_as_inactive"] = "علامت گذاری به عنوان غیرفعال";
$lang["mark_as_inactive_help_message"] = "کاربران غیرفعال قادر به ورود به سیستم نیستند و در لیست کاربران فعال شمارش نمی شوند!";

$lang["invoice_id"] = "شناسه فاکتور";
$lang["payments"] = "مبلغ پرداختی";
$lang["invoice_sent_message"] = "فاکتور ارسال شد!";
$lang["attached"] = "پیوست شده";
$lang["vat_number"] = "مالیات بر ارزش افزوده";
$lang["invite_an_user"] = "دعوت از کاربر برای %s"; // Invite an user for {company name}
$lang["unit_type"] = "نوع واحد";

/* projects */
$lang["add_project"] = "افزودن پروژه";
$lang["edit_project"] = "ویرایش پروژه";
$lang["delete_project"] = "حذف پروژه";
$lang["project"] = "پروژه";
$lang["projects"] = "پروژها";
$lang["all_projects"] = "تمامی پروژه ها";
$lang["member"] = "عضو";
$lang["overview"] = "بررسی اجمالی";
$lang["project_members"] = "اعضای پروژه";
$lang["add_member"] = "افزودن عضو";
$lang["delete_member"] = "افزودن عضو";
$lang["start_timer"] = "شروع تایمر";
$lang["stop_timer"] = "توقف تایمر";
$lang["project_timeline"] = "جدول زمانی پروژه";
$lang["open_projects"] = "پروژه های در حال اجرا";
$lang["projects_completed"] = "پروژه ها به پایان رسید";
$lang["progress"] = "پیشرفت";
$lang["activity"] = "فعالیت";
$lang["started_at"] = "شروع شده در";
$lang["customer_feedback"] = "بازخورد مشتری";
$lang["project_comment_reply"] = "پاسخ نظری در مورد پروژه";
$lang["task_comment_reply"] = "پاسخ نظری در مورد وظیفه";
$lang["file_comment_reply"] = "پاسخ نظری در مورد فایل   ";
$lang["customer_feedback_reply"] = "پاسخ بازخورد مشتری";

/* expense */
$lang["add_category"] = "افزودن دسته بندی";
$lang["edit_category"] = "ویرایش دسته بندی";
$lang["delete_category"] = "حذف دسته بندی";
$lang["category"] = "دسته بندی";
$lang["categories"] = "دسته بندی ها";
$lang["expense_categories"] = "دسته بندی های هزینه";
$lang["add_expense"] = "افزودن هزینه";
$lang["edit_expense"] = "ویرایش هزینه";
$lang["delete_expense"] = "حذف هزینه";
$lang["expense"] = "هزینه";
$lang["expenses"] = "هزینه ها";
$lang["date_of_expense"] = "تاریخ هزینه";
$lang["finance"] = "دارایی";

/* notes */
$lang["add_note"] = "افزودن یادداشت";
$lang["edit_note"] = "ویرایش یادداشت";
$lang["delete_note"] = "حذف یادداشت";
$lang["note"] = "یادداشت";
$lang["notes"] = "یادداشت ها";
$lang["sticky_note"] = "یادداشت های مهم )شخصی(";

/* history */
$lang["history"] = "تاریخچه";

/* timesheet */
$lang["timesheets"] = "برگه های زمانی";
$lang["log_time"] = "زمان ورود به سیستم";
$lang["edit_timelog"] = "ویرایش جدول زمانی";
$lang["delete_timelog"] = "حذف جدول زمانی";
$lang["timesheet_statistics"] = "آمار برگه های زمانی";

/* milestones */
$lang["add_milestone"] = "Add milestone";
$lang["edit_milestone"] = "Edit milestone";
$lang["delete_milestone"] = "Delete milestone";
$lang["milestone"] = "Milestone";
$lang["milestones"] = "Milestones";

/* files */
$lang["add_files"] = "افزودن فایل";
$lang["edit_file"] = "ویرایش فایل";
$lang["delete_file"] = "حذف فایل";
$lang["file"] = "فایل";
$lang["files"] = "فایل ها";
$lang["file_name"] = "نام فایل";
$lang["size"] = "اندازه";
$lang["uploaded_by"] = "آپلود شده توسط";
$lang["accepted_file_format"] = "فرمت فایل پذیرفته شده";
$lang["comma_separated"] = "جدا شده با ویرگول";
$lang["project_file"] = "فایل";
$lang["download"] = "دانلود";
$lang["download_files"] = "دانلود %s فایل"; //Ex. Download 4 files
$lang["file_preview_is_not_available"] = "پیش نمایش فایل در دسترس نیست.";

/* tasks */
$lang["add_task"] = "افزودن کار";
$lang["edit_task"] = "ویرایش کار";
$lang["delete_task"] = "حذف کار";
$lang["task"] = "کار";
$lang["tasks"] = "کار ها";
$lang["my_tasks"] = "کار های من";
$lang["my_open_tasks"] = "کار های در حال اجرای من";
$lang["assign_to"] = "اختصاص به";
$lang["assigned_to"] = "اختصاص یافته به";
$lang["labels"] = "پرچسب ها";
$lang["to_do"] = "انجام دادن";
$lang["in_progress"] = "در حال پیشرفت";
$lang["done"] = "انجام شده";
$lang["task_info"] = "اطلاعات کار";
$lang["points"] = "Points";
$lang["point"] = "Point";
$lang["task_status"] = "وضعیت کار";

/* comments */
$lang["comment"] = "نظر";
$lang["comments"] = "نظرات";
$lang["write_a_comment"] = "نوشتن نظر...";
$lang["write_a_reply"] = "نوشتن پاسخ...";
$lang["post_comment"] = "ارسال نظر";
$lang["post_reply"] = "ارسال پاسخ";
$lang["reply"] = "پاسخ";
$lang["replies"] = "پاسخ ها";
$lang["like"] = "like";
$lang["unlike"] = "unlike";
$lang["view"] = "بازدید";
$lang["project_comment"] = "نظر در مورد پروژه";
$lang["task_comment"] = "نظر در مورد تسک";
$lang["file_comment"] = "نظر در مورد فایل";

/* time format */
$lang["today"] = "امروز";
$lang["yesterday"] = "دیروز";
$lang["tomorrow"] = "فردا";

$lang["today_at"] = "امروز در";
$lang["yesterday_at"] = "دیروز در";

/* tickets */

$lang["add_ticket"] = "افزودن تیکت";
$lang["ticket"] = "تیکت";
$lang["tickets"] = "تیکت ها";
$lang["ticket_id"] = "شناسه تیکت";
$lang["client_replied"] = "Client replied";
$lang["change_status"] = "تغییر وضعیت";
$lang["last_activity"] = "آخرین فعالیت";
$lang["open_tickets"] = "تیکت های فعال";
$lang["ticket_status"] = "وضعیت تیکت";

/* ticket types */

$lang["add_ticket_type"] = "افزدون نوع تیکت";
$lang["ticket_type"] = "نوع تیکت";
$lang["ticket_types"] = "انواع تیکت";
$lang["edit_ticket_type"] = "ویرایش نوع تیکت";
$lang["delete_ticket_type"] = "حذف نوع تیکت";

/* payment methods */

$lang["add_payment_method"] = "افزودن روش پرداخت";
$lang["payment_method"] = "روش پرداخت";
$lang["payment_methods"] = "روش های پرداخت";
$lang["edit_payment_method"] = "تغییر روش پرداخت";
$lang["delete_payment_method"] = "حذف روش پرداخت";

/* invoices */

$lang["add_invoice"] = "افزودن فاکتور";
$lang["edit_invoice"] = "ویرایش فاکتور";
$lang["delete_invoice"] = "حذف فاکتور";
$lang["invoice"] = "فاکتور";
$lang["invoices"] = "فاکتور ها";
$lang["bill_date"] = "تاریخ قبض";
$lang["due_date"] = "تاریخ سررسید";
$lang["payment_date"] = "تاریخ پرداخت";
$lang["bill_to"] = "قبض برای";
$lang["invoice_value"] = "قیمت فاکتور";
$lang["payment_received"] = "دریافتی";
$lang["invoice_payments"] = "مبلغ پرداختی";
$lang["draft"] = "پیش نویس";
$lang["fully_paid"] = "تسویه شده";
$lang["partially_paid"] = "پرداخت جزی";
$lang["not_paid"] = "پرداخت نشده";
$lang["overdue"] = "منقضی شده";
$lang["invoice_items"] = "کالاهای فاکتور";
$lang["edit_invoice"] = "ویرایش فاکتور";
$lang["delete_invoice"] = "حذف فاکتور";
$lang["item"] = "کالا";
$lang["add_item"] = "افزودن کالا";
$lang["create_new_item"] = "ساخت یک کالای جدید";
$lang["select_or_create_new_item"] = "از لیست انتخاب کنید یا یک کالای جدید بسازید...";
$lang["quantity"] = "تعداد";
$lang["rate"] = "نرخ";
$lang["total_of_all_pages"] = "کل صفحات";
$lang["sub_total"] = "Sub Total";
$lang["total"] = "مجموع";
$lang["last_email_sent"] = "اخرین ایمیل ارسال شده";
$lang["item_library"] = "Item library";
$lang["add_payment"] = "افزودن پرداختی";
$lang["never"] = "هیجوقت";
$lang["email_invoice_to_client"] = "ایمیل کردن فاکتور برای مشتری";
$lang["download_pdf"] = "دانلود PDF";
$lang["print"] = "پرینت";
$lang["actions"] = "Actions";
$lang["balance_due"] = "Balance Due";
$lang["paid"] = "پرداخت شده";
$lang["amount"] = "تعداد";
$lang["invoice_payment_list"] = "لیست پرداخت فاکتور";
$lang["invoice_statistics"] = "آمار فاکتور";
$lang["payment"] = "پرداخت";

/* email templates */
$lang["email_templates"] = "قالب ایمیل";
$lang["select_a_template"] = "انتخاب یک قالب برای تغییر";
$lang["avilable_variables"] = "متغیرهای موجود";
$lang["restore_to_default"] = "بازیابی به حالت پیشفرض";
$lang["template_restored"] = "قالب به حالت پیشفرض بازگشت.";
$lang["login_info"] = "اطلاعات ورود";
$lang["reset_password"] = "بازنشانی رمز عبور";
$lang["team_member_invitation"] = "دعوت از اعضای تیم";
$lang["client_contact_invitation"] = "دعوتنامه تماس با مشتری";
$lang["send_invoice"] = "ارسال فاکتور";
$lang["signature"] = "امضا";

/* roles */

$lang["role"] = "قانون";
$lang["roles"] = "قوانین";
$lang["add_role"] = "افزودن قانون";
$lang["edit_role"] = "ویرایش قانون";
$lang["delete_role"] = "حذف قانون";
$lang["use_seetings_from"] = "استفاده از تنظیمات";
$lang["permissions"] = "مجوز ها";
$lang["yes_all_members"] = "بله، همه اعضا";
$lang["yes_specific_members_or_teams"] = "بله ، اعضا یا تیم های خاصی";
$lang["yes_specific_ticket_types"] = "بله ، انواع تیکت های خاص";
$lang["select_a_role"] = "انتخاب یک قانون";
$lang["choose_members_and_or_teams"] = "اعضا یا تیم ها را انتخاب کنید";
$lang["choose_ticket_types"] = "انتخاب نوع تیکت ها";
$lang["excluding_his_her_time_cards"] = "Excluding his/her own time cards";
$lang["excluding_his_her_leaves"] = "Excluding his/her own leaves";
$lang["can_manage_team_members_leave"] = "Can manage team member's leaves?";
$lang["can_manage_team_members_timecards"] = "Can manage team member's time cards?";
$lang["can_access_invoices"] = "به فاکتورها دسترسی داشته باشد؟";
$lang["can_access_expenses"] = "به هزینه ها دسترسی داشته باشد؟";
$lang["can_access_clients_information"] = "به اطلاعات مشتری دسترسی داشته باشد؟";
$lang["can_access_tickets"] = "به تیکت ها دسترسی داشته باشد?";
$lang["can_manage_announcements"] = "آیا اطلاعیه ها را مدیریت کند?";

/* timeline */
$lang["post_placeholder_text"] = "به اشتراک گذاری یک ایده و یا مدارک...";
$lang["post"] = "پست";
$lang["timeline"] = "جدول زمانی";
$lang["load_more"] = "بارگذاری بیشتر";
$lang["upload_file"] = "آپلود فایل";
$lang["upload"] = "آپلود";
$lang["new_posts"] = "پست های جدید";

/* taxes */

$lang["add_tax"] = "افزودن مالیات";
$lang["tax"] = "مالیات";
$lang["taxes"] = "مالیات ها";
$lang["edit_tax"] = "ویرایش مالیات";
$lang["delete_tax"] = "حذف مالیات";
$lang["percentage"] = "درصد (%)";
$lang["second_tax"] = "مالیات دوم";

/* Version 1.2 */
$lang["available_on_invoice"] = "موجود در فاکتور";
$lang["available_on_invoice_help_text"] = "روش پرداخت در فاکتورهای مشتری نشان داده خواهد شد.";
$lang["minimum_payment_amount"] = "حداقل مبلغ پرداختی";
$lang["minimum_payment_amount_help_text"] = "اگر ارزش فاکتور کمتر از این مقدار باشد ، مشتریان نمی توانند فاکتور را با استفاده از این روش پرداخت بپردازند.";
$lang["pay_invoice"] = "پرداخت فاکتور";
$lang["pay_button_text"] = "متن کلید پرداخت";
$lang["minimum_payment_validation_message"] = "حد حداقل مبلغ پرداختی: "; //ex. The payment amount can't be less then: USD 100.00
$lang["invoice_settings"] = "تنظیمات فاکتور";
$lang["allow_partial_invoice_payment_from_clients"] = "اجازه پرداخت جزیی از مشتریان";
$lang["invoice_color"] = "رنگ فاکتور";
$lang["invoice_footer"] = "پاورقی فاکتور";
$lang["invoice_preview"] = "پیش نمایش فاکتور";
$lang["close_preview"] = "بستن پیش نمایش";
$lang["only_me"] = "فقط برای من";
$lang["specific_members_and_teams"] = "اعضا و تیم های خاص";
$lang["rows_per_page"] = "تعداد سطرها در هر صفحه";
$lang["price"] = "قیمت";
$lang["security_type"] = "نوع امنیت";

$lang["client_can_view_tasks"] = "مشتری می تواند وظایف را مشاهده کند؟";
$lang["client_can_create_tasks"] = "مشتری می تواند وظایف را ایجاد کند؟";
$lang["client_can_edit_tasks"] = "مشتری می تواند وظایف را ویرایش کند؟";
$lang["client_can_comment_on_tasks"] = "مشتری می تواند در مورد وظایف، نظر بدهد؟";

$lang["set_project_permissions"] = "تعیین مجوزهای پروژه";
$lang["can_create_projects"] = "بتواند پروژه ها را ایجاد کند";
$lang["can_edit_projects"] = "بتواند پروژه ها را ویرایش کند";
$lang["can_delete_projects"] = "بتواند پروژه ها را حذف کند";
$lang["can_create_tasks"] = "بتواند وظایف را ایجاد کند";
$lang["can_edit_tasks"] = "بتواند وظایف را ویرایش کند";
$lang["can_delete_tasks"] = "بتواند وظایف را حذف کند";
$lang["can_comment_on_tasks"] = "بتواند در مورد وظایف نظر بدهد";
$lang["can_create_milestones"] = "Can create milestones";
$lang["can_edit_milestones"] = "Can edit milestones";
$lang["can_delete_milestones"] = "Can delete milestones";
$lang["can_add_remove_project_members"] = "بتواند اعضای پروژه را اضافه/حذف کند";
$lang["can_delete_files"] = "بتواند فایل ها را حذف کند";

/* Version 1.2.2 */
$lang["label"] = "برچسب";
$lang["send_bcc_to"] = "هنگام ارسال فاکتور به مشتری، یک نسخه از آن را از طریق bcc ارسال کن به";
$lang["mark_project_as_completed"] = "علامت گذاری پروژه به عنوان انجام شده";
$lang["mark_project_as_canceled"] = "علامت گذاری پروژه به عنوان لغو شده";
$lang["mark_project_as_open"] = "علامت گذاری پروژه به عنوان پروژه باز";

/* Version 1.3 */
$lang["notification"] = "اعلان";
$lang["notifications"] = "اعلان ها";
$lang["notification_settings"] = "تنظیمات اعلان";
$lang["enable_email"] = "فعالسازی ایمیل";
$lang["enable_web"] = "فعالسازی وب";
$lang["event"] = "رویداد";
$lang["notify_to"] = "اطلاع رسانی به";

$lang["project_created"] = "پروژه ایجاد شد";
$lang["project_deleted"] = "پروژه حذف شد";
$lang["project_task_created"] = "وظیفه پروژه ایجاد شد";
$lang["project_task_updated"] = "وظیفه پروژه به روز رسانی شد";
$lang["project_task_assigned"] = "وظیفه پروژه واگذار شد";
$lang["project_task_started"] = "وظیفه پروژه شروع شد";
$lang["project_task_finished"] = "وظیفه پروژه به پایان رسید";
$lang["project_task_reopened"] = "وظیفه پروژه دوباره باز شد";
$lang["project_task_deleted"] = "وظیفه پروژه حذف شد";
$lang["project_task_commented"] = "Project task commented";
$lang["project_member_added"] = "عضو پروژه اضافه شد";
$lang["project_member_deleted"] = "عضو پروژه حذف شد";
$lang["project_file_added"] = "فایل پروژه اضافه شد";
$lang["project_file_deleted"] = "فایل پروژه حذف شد";
$lang["project_file_commented"] = "نظری در مورد فایل پروژه داده شد";
$lang["project_comment_added"] = "نظری در مورد پروژه اضافه شد";
$lang["project_comment_replied"] = "به نظر در مورد پروژه، پاسخ داده شد";
$lang["project_customer_feedback_added"] = "بازخورد مشتری پروژه اضافه شد";
$lang["project_customer_feedback_replied"] = "به بازخورد مشتری پروژه پاسخ داده شد";
$lang["client_signup"] = "ثبت نام مشتری";
$lang["invoice_online_payment_received"] = "فاکتور پرداخت آنلاین دریافت شد";
$lang["leave_application_submitted"] = "درخواست مرخصی ثبت شد";
$lang["leave_approved"] = "با مرخصی موافقت شد";
$lang["leave_assigned"] = "مرخصی واگذار شد";
$lang["leave_rejected"] = "مرخصی رد شد";
$lang["leave_canceled"] = "مرخصی لغو شد";
$lang["ticket_created"] = "تیکت ایجاد شد";
$lang["ticket_commented"] = "بر روی تیکت کامنت گذاری شد";
$lang["ticket_closed"] = "تیکت بسته شد";
$lang["ticket_reopened"] = "تیکت دوباره باز شد";
$lang["leave"] = "مرخصی";

$lang["client_primary_contact"] = "ارتباط اولیه ی مشتری";
$lang["client_all_contacts"] = "تمامی ارتباطات مشتری";
$lang["task_assignee"] = "مسئول وظیفه";
$lang["task_collaborators"] = "همکاران وظیفه";
$lang["comment_creator"] = "ایجاد کننده ی نظر";
$lang["leave_applicant"] = "درخواست کننده ی مرخصی";
$lang["ticket_creator"] = "ایجاد کننده ی تیکت";

$lang["no_new_notifications"] = "اعلانی یافت نشد.";

/* Notification messages */

$lang["notification_project_created"] = "پروژه ی جدیدی ایجاد کرد.";
$lang["notification_project_deleted"] = "پروژه ای را حذف کرد.";
$lang["notification_project_task_created"] = "وظیفه ی جدیدی را ایجاد کرد.";
$lang["notification_project_task_updated"] = "وظیفه ای را به روز رسانی کرد.";
$lang["notification_project_task_assigned"] = "وظیفه ای را واگذار کرد به %s"; //Assigned a task to Mr. X
$lang["notification_project_task_started"] = "وظیفه ای را شروع کرد.";
$lang["notification_project_task_finished"] = "وظیفه ای را به پایان رساند.";
$lang["notification_project_task_reopened"] = "وظیفه ای را دوباره باز کرد.";
$lang["notification_project_task_deleted"] = "وظیفه ای را حذف کرد.";
$lang["notification_project_task_commented"] = "در مورد وظیفه ای نظر گذاشت.";
$lang["notification_project_member_added"] = "%s را در پروژه ای اضافه کرد."; //Added Mr. X in a project.
$lang["notification_project_member_deleted"] = "%s را از پروژه ای حذف کرد."; //Deleted Mr. X from a project.
$lang["notification_project_file_added"] = "فایلی در پروژه اضافه کرد.";
$lang["notification_project_file_deleted"] = "فایلی از پروژه حذف کرد.";
$lang["notification_project_file_commented"] = "در مورد فایلی نظر گذاشت.";
$lang["notification_project_comment_added"] = "در مورد پروژه ای نظر گذاشت.";
$lang["notification_project_comment_replied"] = "به نظر روی پروژه ای پاسخ داد.";
$lang["notification_project_customer_feedback_added"] = "بر روی پروژه ای نظر گذاشت.";
$lang["notification_project_customer_feedback_replied"] = "به نظری پاسخ داد.";
$lang["notification_client_signup"] = "به عنوان مشتری جدید ثبت نام کرد."; //Mr. X signed up as a new client.
$lang["notification_invoice_online_payment_received"] = "پرداخت آنلاینی را ثبت کرد.";
$lang["notification_leave_application_submitted"] = "یک درخواست مرخصی ثبت کرد.";
$lang["notification_leave_approved"] = "با مرخصی %s موافقت کرد."; //Approved a leave of Mr. X
$lang["notification_leave_assigned"] = "مرخصی را به %s واگذار کرد."; //Assigned a leave to Mr. X
$lang["notification_leave_rejected"] = "مرخصی %s را رد کرد %s."; //Approve a leave of Mr. X
$lang["notification_leave_canceled"] = "یک درخواست مرخصی را لغو کرد.";
$lang["notification_ticket_created"] = "تیکت جدیدی ایجاد کرد.";
$lang["notification_ticket_commented"] = "در مورد تیکتی نظر گذاشت.";
$lang["notification_ticket_closed"] = "تیکت را بست.";
$lang["notification_ticket_reopened"] = "تیکت را دوباره باز کرد.";

$lang["general_notification"] = "اعلان عمومی";

$lang["disable_online_payment"] = "غیرفعال کردن پرداخت آنلاین";
$lang["disable_online_payment_description"] = "پنهان کردن گزینه های پرداخت آنلاین در فاکتور این مشتری.";

$lang["client_can_view_project_files"] = "مشتری بتواند فایل های پروژه را ببیند؟";
$lang["client_can_add_project_files"] = "مشتری بتواند فایل های پروژه را اضافه کند؟";
$lang["client_can_comment_on_files"] = "مشتری بتواند در مورد فایل ها نظر بگذارد؟";
$lang["mark_invoice_as_not_paid"] = "علامت گذاری به عنوان پرداخت نشده"; //Change invoice status to Not Paid

$lang["set_team_members_permission"] = "تعیین مجوزهای اعضای تیم";
$lang["can_view_team_members_contact_info"] = "بتواند اطلاعات تماس عضو تیم را ببیند؟";
$lang["can_view_team_members_social_links"] = "بتواند لینک های اجتماعی عضو تیم را ببیند؟";

$lang["collaborator"] = "همکار";
$lang["collaborators"] = "همکاران";

/* Version 1.4 */

$lang["modules"] = "ماژول ها";
$lang["manage_modules"] = "مدیریت ماژول ها";
$lang["module_settings_instructions"] = "ماژول هایی را که می خواهید استفاده کنید انتخاب کنید.";

$lang["task_point_help_text"] = "Task point considered as a task value. You can set 5 points for very difficult tasks and 1 point for easy tasks."; //meaning of task point

$lang["mark_as_open"] = "علامت گذاری به عنوان باز";
$lang["mark_as_closed"] = "علامت گذاری به عنوان بسته شده";

$lang["ticket_assignee"] = "مسئول تیکت";

$lang["estimate"] = "برآورد";
$lang["estimates"] = "برآوردها";
$lang["estimate_request"] = "درخواست برآورد";
$lang["estimate_requests"] = "درخواست های برآورد";
$lang["estimate_list"] = "لیست برآورد";
$lang["estimate_forms"] = "فرم های برآورد";
$lang["estimate_request_forms"] = "فرم های درخواست برآورد";

$lang["add_form"] = "افزودن فرم";
$lang["edit_form"] = "ویرایش فرم";
$lang["delete_form"] = "حذف فرم";

$lang["add_field"] = "افزودن فیلد";
$lang["placeholder"] = "Placeholder";
$lang["required"] = "الزامی";

$lang["field_type"] = "نوع فیلد";
$lang["preview"] = "پیش نمایش";

$lang["field_type_text"] = "متن";
$lang["field_type_textarea"] = "Textarea";
$lang["field_type_select"] = "انتخاب";
$lang["field_type_multi_select"] = "انتخاب چندگانه";

$lang["request_an_estimate"] = "درخواست یک برآورد";
$lang["estimate_submission_message"] = "درخواست شما با موفقیت ثبت شد!";

$lang["hold"] = "انتظار";
$lang["processing"] = "در حال پردازش";
$lang["estimated"] = "تخمین زده شد";

$lang["add_estimate"] = "افزودن برآورد";
$lang["edit_estimate"] = "ویرایش برآورد";
$lang["delete_estimate"] = "حذف برآورد";
$lang["valid_until"] = "معتبر تا";
$lang["estimate_date"] = "تاریخ برآورد";
$lang["accepted"] = "پذیرفته شد";
$lang["declined"] = "رد شد";
$lang["sent"] = "ارسال شد";
$lang["estimate_preview"] = "پیش نمایش برآورد";
$lang["estimate_to"] = "Estimate To";

$lang["can_access_estimates"] = "به تخمین ها دسترسی داشته باشد؟";
$lang["request_an_estimate"] = "درخواست یک برآورد";
$lang["estimate_request_form_selection_title"] = "لطفا برای ارسال درخواست خود، فرم را از لیست زیر انتخاب کنید.";

$lang["mark_as_processing"] = "علامت گذاری به عنوان در حال پردازش";
$lang["mark_as_estimated"] = "علامت گذاری به عنوان برآورد شده";
$lang["mark_as_hold"] = "علامت گذاری به عنوان در انتظار";
$lang["mark_as_canceled"] = "علامت گذاری به عنوان لغو شده";

$lang["mark_as_sent"] = "علامت گذاری به عنوان ارسال شده";
$lang["mark_as_accepted"] = "علامت گذاری به عنوان پذیرفته شده";
$lang["mark_as_rejected"] = "علامت گذاری به عنوان رد شده";
$lang["mark_as_declined"] = "علامت گذاری به عنوان رد شده";

$lang["estimate_request_received"] = "درخواست برآورد دریافت شد";
$lang["estimate_sent"] = "برآورد ارسال شد";
$lang["estimate_accepted"] = "برآورد پذیرفته شد";
$lang["estimate_rejected"] = "برآورد رد شد";

$lang["notification_estimate_request_received"] = "درخواست برآوردی را ثبت کرد";
$lang["notification_estimate_sent"] = "برآوردی را ارسال کرد";
$lang["notification_estimate_accepted"] = "برآوردی را پذیرفت";
$lang["notification_estimate_rejected"] = "برآوردی را رد کرد";

$lang["clone_project"] = "ساخت نسخه ی دومی از پروژه";
$lang["copy_tasks"] = "کپی کردن وظایف";
$lang["copy_project_members"] = "کپی کردن اعضای پروژه";
$lang["copy_milestones"] = "Copy milestones";
$lang["copy_same_assignee_and_collaborators"] = "Copy same assignee and collaborators";
$lang["copy_tasks_start_date_and_deadline"] = "کپی کردن تاریخ شروع و موعد وظایف";
$lang["task_comments_will_not_be_included"] = "نظرات وظایف شامل نمی شود";
$lang["project_cloned_successfully"] = "نسخه ی دومی از پروژه با موفقیت ساخته شد";

$lang["search"] = "جستجو";
$lang["no_record_found"] = "رکوردی یافت نشد.";
$lang["excel"] = "اکسل";
$lang["print_button_help_text"] = "هنگام خاتمه کلید escape را فشار دهید.";
$lang["are_you_sure"] = "آیا مطمئن هستید?";
$lang["file_upload_instruction"] = "مدارک را بکشید و در اینجا رها کنید <br /> (و یا برای انتخاب فایل ها کلید کنید...)";
$lang["file_name_too_long"] = "اسم فایل بیش از حد طولانی است.";
$lang["scrollbar"] = "Scrollbar";

$lang["short_sunday"] = "Sun";
$lang["short_monday"] = "Mon";
$lang["short_tuesday"] = "Tue";
$lang["short_wednesday"] = "Wed";
$lang["short_thursday"] = "Thu";
$lang["short_friday"] = "Fri";
$lang["short_saturday"] = "Sat";

$lang["min_sunday"] = "Su";
$lang["min_monday"] = "Mo";
$lang["min_tuesday"] = "Tu";
$lang["min_wednesday"] = "We";
$lang["min_thursday"] = "Th";
$lang["min_friday"] = "Fr";
$lang["min_saturday"] = "Sa";

$lang["january"] = "ژانویه";
$lang["february"] = "فوریه";
$lang["march"] = "مارس";
$lang["april"] = "آوریل";
$lang["may"] = "می";
$lang["june"] = "ژوئن";
$lang["july"] = "جولای";
$lang["august"] = "آگوست";
$lang["september"] = "سپتامبر";
$lang["october"] = "اکتبر";
$lang["november"] = "نوامبر";
$lang["december"] = "دسامبر";

$lang["short_january"] = "Jan";
$lang["short_february"] = "Feb";
$lang["short_march"] = "Mar";
$lang["short_april"] = "Apr";
$lang["short_may"] = "May";
$lang["short_june"] = "Jun";
$lang["short_july"] = "Jul";
$lang["short_august"] = "Aug";
$lang["short_september"] = "Sep";
$lang["short_october"] = "Oct";
$lang["short_november"] = "Nov";
$lang["short_december"] = "Dec";

/* Version 1.5 */

$lang["no_such_file_or_directory_found"] = "چنین فایل و یا مسیری وجود ندارد.";
$lang["gantt"] = "گانت";
$lang["not_specified"] = "مشخص نشده است";
$lang["group_by"] = "گروه بندی توسط";
$lang["create_invoice"] = "ایجاد فاکتور";
$lang["include_all_items_of_this_estimate"] = "همه ی موارد این برآورد را شامل شود";
$lang["edit_payment"] = "ویرایش پرداخت";
$lang["disable_client_login"] = "غیرفعال سازی ورود مشتری";
$lang["disable_client_signup"] = "غیرفعال سازی ثبت نام مشتری";

$lang["chart"] = "نمودار";
$lang["signin_page_background"] = "پس زمینه ی صفحه ی ورود";
$lang["show_logo_in_signin_page"] = "نشان دادن لوگو در صفحه ی ورود";
$lang["show_background_image_in_signin_page"] = "نشان داده تصویر پس زمینه در صفحه ی ورود";

/* Version 1.6 */

$lang["more"] = "بیشتر";
$lang["custom"] = "سفارشی";
$lang["clear"] = "پاک کردن";
$lang["expired"] = "منقضی";
$lang["enable_attachment"] = "فعال سازی پیوست";
$lang["custom_fields"] = "فیلدهای سفارشی";
$lang["edit_field"] = "قسمت ویرایش";
$lang["delete_field"] = "قسمت حذف";
$lang["client_info"] = "اطلاعات مشتری";
$lang["edit_expenses_category"] = "ویرایش دسته بندی هزینه ها";
$lang["eelete_expenses_category"] = "حذف دسته بندی هزینه ها";
$lang["empty_starred_projects"] = "برای دسترسی سریع به پروژه های مورد علاقه خود ، لطفاً به نمای پروژه بروید و ستاره را علامت گذاری کنید";
$lang["empty_starred_clients"] = "برای دسترسی سریع به مشتری های مورد علاقه خود ، لطفاً به نمای مشتری بروید و ستاره را علامت گذاری کنید.";
$lang["download_zip_name"] = "مدارک";
$lang["invoice_prefix"] = "شماره ی شاخص فاکتور";
$lang["invoice_style"] = "Invoice style";
$lang["delete_confirmation_message"] = " آیا مطمئن هستید؟ نمی توانید این عمل را برگردانید!";
$lang["left"] = "چپ";
$lang["right"] = "راست";
$lang["currency_position"] = "Currency Position";
$lang["recipient"] = "گیرنده";

$lang["new_message_sent"] = "پیام جدید ارسال شد";
$lang["message_reply_sent"] = "به پیام، پاسخ داده شد";
$lang["notification_new_message_sent"] = "پیامی را ارسال کرد.";
$lang["notification_message_reply_sent"] = "به پیامی پاسخ داد.";
$lang["invoice_payment_confirmation"] = "تایید پرداخت فاکتور";
$lang["notification_invoice_payment_confirmation"] = "پرداخت دریافت شد";

/* Version 1.7 */

$lang["client_can_create_projects"] = "مشتری بتواند پروژه ها را ایجاد کند؟";
$lang["client_can_view_timesheet"] = "مشتری بتواند برگه زمانی را مشاهده کند؟?";
$lang["client_can_view_gantt"] = "مشتری بتواند گانت را مشاهده کند؟";
$lang["client_can_view_overview"] = "مشتری بتواند نمای کلی پروژه را مشاهده کند؟";
$lang["client_can_view_milestones"] = "Client can view milestones?";

$lang["items"] = "موارد";
$lang["edit_item"] = "ویرایش مورد";
$lang["item_edit_instruction"] = "توجه: تغییرات، روی فاکتورهای موجود و یا برآورد تأثیر نخواهد گذاشت.";

$lang["recurring"] = "تکرار شونده";
$lang["repeat_every"] = "تکرار شود هر"; //Ex. repeat every 2 months
$lang["interval_days"] = "روز(ها)";
$lang["interval_weeks"] = "هفته(ها)";
$lang["interval_months"] = "ماه(ها)";
$lang["interval_years"] = "سال(ها)";
$lang["cycles"] = "چرخه ها";
$lang["recurring_cycle_instructions"] = "تکرارشوندگی پس از تعداد چرخه ها متوقف خواهد شد. جهت تکرار بینهایت، مقدار آن را خالی نگه دارید";
$lang["next_recurring_date"] = "تکرار بعدی";
$lang["stopped"] = "متوقف شد";
$lang["past_recurring_date_error_message_title"] = "صورتحساب انتخابی و نوع تکرار یک تاریخ گذشته را بر میگرداند.";
$lang["past_recurring_date_error_message"] = "تاریخ تکرار بعدی باید تاریخ آینده باشد. لطفاً تاریخ آینده را وارد کنید.";
$lang["sub_invoices"] = "فاکتورهای فرعی";

$lang["cron_job_required"] = "Cron Job is required for this action!";

$lang["recurring_invoice_created_vai_cron_job"] = "Recurring invoice created via Cron Job";
$lang["notification_recurring_invoice_created_vai_cron_job"] = "فاکتور جدید ایجاد شد";

$lang["field_type_number"] = "شماره";
$lang["show_in_table"] = "نمایش در جدول";
$lang["show_in_invoice"] = "نمایش در فاکتور";
$lang["visible_to_admins_only"] = "قابل مشاهده تنها برای مدیران";
$lang["hide_from_clients"] = "پنهان سازی از مشتریان";
$lang["public"] = "عمومی";

$lang["help"] = "راهنما";
$lang["articles"] = "مقالات";
$lang["add_article"] = "افزودن مقاله ی جدید";
$lang["edit_article"] = "ویرایش مقاله";
$lang["delete_article"] = "حذف مقاله";
$lang["can_manage_help_and_knowledge_base"] = "بتواند راهنما و پایگاه دانش را مدیریت کند؟";

$lang["how_can_we_help"] = "چگونه میتوانیم کمک کنیم؟";
$lang["help_page_title"] = "ویکی داخلی";
$lang["search_your_question"] = "پرسش خود را جستجو کنید";
$lang["no_result_found"] = "نتیجه ای یافت نشد.";
$lang["sort"] = "مرتب سازی";
$lang["total_views"] = "تعداد کل بازدیدها";

$lang["help_and_support"] = "راهنما و پشتیبانی";
$lang["knowledge_base"] = "پایگاه دانش";

$lang["payment_success_message"] = "پرداخت شما به پایان رسیده است.";
$lang["payment_card_charged_but_system_error_message"] = "ممکن است از حساب کارت شما کسر شده باشد اما ما نمی توانیم روند کار را کامل کنیم. لطفاً با مدیر سیستم خود تماس بگیرید";
$lang["card_payment_failed_error_message"] = "اکنون نمی توانیم پرداخت شما را پردازش کنیم ، لطفاً پس از مدتی دوباره امتحان کنید.";

$lang["message_received"] = "پیام دریافت شد";
$lang["in_number_of_days"] = "در %s روز"; //Ex. In 7 days
$lang["details"] = "جزییات";
$lang["summary"] = "خلاصه";
$lang["project_timesheet"] = "برگه زمانی پروژه";

$lang["set_event_permissions"] = "تعیین مجوزهای رویداد";
$lang["disable_event_sharing"] = "غیرفعال سازی اشتراک رویداد";
$lang["can_update_team_members_general_info_and_social_links"] = "بتواند اطلاعات عمومی و لینک های اجتماعی عضو تیم را به روز رسانی کند؟";
$lang["can_manage_team_members_project_timesheet"] = "بتواند برگه زمانی پروژه ی عضو تیم را مدیریت کند؟";

$lang["cron_job"] = "Cron Job";
$lang["cron_job_link"] = "Cron Job link";
$lang["last_cron_job_run"] = "Last Cron Job run";
$lang["created_from"] = "Created from"; //Ex. Created from Invoice#1
$lang["recommended_execution_interval"] = "Recommended execution interval";

/* Version 1.8 */

$lang["integration"] = "Integration";
$lang["get_your_key_from_here"] = "Get your key from here:";
$lang["re_captcha_site_key"] = "Site key";
$lang["re_captcha_secret_key"] = "Secret key";

$lang["re_captcha_error-missing-input-secret"] = "reCAPTCHA secret is missing";
$lang["re_captcha_error-invalid-input-secret"] = "reCAPTCHA secret is not valid.";
$lang["re_captcha_error-missing-input-response"] = "Please select the reCAPTCHA.";
$lang["re_captcha_error-invalid-input-response"] = "The response parameter is invalid or malformed.";
$lang["re_captcha_error-bad-request"] = "The request is invalid or malformed.";
$lang["re_captcha_expired"] = "The reCAPTCHA has been expired. Please reload the page.";

$lang["yes_all_tickets"] = "Yes, all tickets";
$lang["choose_ticket_types"] = "Choose ticket types";

$lang["can_manage_all_projects"] = "Can manage all projects";
$lang["show_most_recent_ticket_comments_at_the_top"] = "Show most recent ticket comments at the top";

$lang["new_event_added_in_calendar"] = "New event added in calendar";
$lang["notification_new_event_added_in_calendar"] = "Added a new event.";

$lang["todo"] = "To do";
$lang["add_a_todo"] = "Add a to do...";

/* Version 1.9 */

$lang["client_groups"] = "Client groups";
$lang["add_client_group"] = "Add client group";
$lang["edit_client_group"] = "Edit client group";
$lang["delete_client_group"] = "Delete client group";

$lang["ticket_prefix"] = "Ticket prefix";
$lang["add_a_task"] = "Add a task...";

$lang["add_task_status"] = "Add task status";
$lang["edit_task_status"] = "Edit task status";
$lang["delete_task_status"] = "Delete task status";

$lang["list"] = "List";
$lang["kanban"] = "Kanban";
$lang["priority"] = "Priority";
$lang["moved_up"] = "Moved Up";
$lang["moved_down"] = "Moved Down";
$lang["mark_project_as_hold"] = "Mark Project as Hold";

$lang["repeat"] = "Repeat";

$lang["hide_team_members_list"] = "Hide team members list?";

/* Version 2.0 */

$lang["summary_details"] = "Summary details";

$lang["chat"] = "Chat";
$lang["my_preferences"] = "My preferences";
$lang["show_push_notification"] = "Show push notification";
$lang["notification_sound_volume"] = "Notification sound volume";

$lang["project_reference_in_tickets"] = "Enable project reference";

$lang["hide_menus_from_client_portal"] = "Hide menus from client portal";
$lang["hidden_menus"] = "Hidden menus";

$lang["new_announcement_created"] = "New announcement created";
$lang["notification_new_announcement_created"] = "Created an announcement.";

$lang["month"] = "Month";
$lang["profit"] = "Profit";

$lang["invoice_due_reminder_before_due_date"] = "Invoice due reminder before due date";
$lang["send_due_invoice_reminder_notification_before"] = "Send due invoice reminder before due date";
$lang["send_invoice_overdue_reminder_after"] = "Send invoice overdue reminder after";
$lang["invoice_overdue_reminder"] = "Invoice overdue reminder";
$lang["recurring_invoice_creation_reminder"] = "Recurring invoice creation reminder";
$lang["send_recurring_invoice_reminder_before_creation"] = "Send recurring invoice reminder before creation";

$lang["notification_invoice_due_reminder_before_due_date"] = "Reminder: Invoice due.";
$lang["notification_invoice_overdue_reminder"] = "Reminder: Invoice overdue";
$lang["notification_recurring_invoice_creation_reminder"] = "An invoice will be generated soon.";

$lang["can_delete_leave_application"] = "Can delete leave application?";
$lang["no_of_decimals"] = "No. of decimals";

$lang["checklist"] = "Checklist";
$lang["delete_checklist_item"] = "Delete checklist item";

$lang["save_and_show"] = "Save & show";
$lang["total_leave_yearly"] = "Total Leave (Yearly)";

$lang["new_conversation"] = "New conversation";

$lang["enable_web_notification"] = "Enable web notification";
$lang["enable_email_notification"] = "Enable email notification";

/* Version 2.0.3 */

$lang["show_in_estimate"] = "Show in estimate";
$lang["mentioned_members"] = "Mentioned members";
$lang["all"] = "All";

$lang["confirmed"] = "Confirmed";
$lang["confirm"] = "Confirm";

$lang["confirmed_by"] = "Confirmed by";
$lang["confirm_event"] = "Confirm event";
$lang["reject_event"] = "Reject event";
$lang["event_status"] = "Event status";

$lang["specific_client_contacts"] = "Specific client contacts";
$lang["choose_client_contacts"] = "Choose client contacts";
$lang["invitations_sent"] = "The invitations has been sent.";

/* Version 2.1 */

$lang["add_new_dashboard"] = "Add new dashboard";
$lang["add_row"] = "Add row";

$lang["available_widgets"] = "Available Widgets";
$lang["your_selected_widgets_will_be_appear_here"] = "Your selected widgets will be appear here";
$lang["drag_and_drop_widgets_here"] = "Drag and drop widgets here";
$lang["no_more_widgets_available"] = "No more widgets available";
$lang["invalid_widget_access"] = "You don't have permission to access this widget";

$lang["dashboard_title"] = "Dashboard title";
$lang["edit_dashboard"] = "Edit dashboard";
$lang["edit_title"] = "Edit title";
$lang["default_dashboard"] = "Default dashboard";

$lang["widget"] = "Widget";
$lang["widgets"] = "Widgets";
$lang["add_widget"] = "Add widget";
$lang["edit_widget"] = "Edit widget";
$lang["delete_widget"] = "Delete widget";

$lang["content"] = "Content";
$lang["clock_in_out"] = "Clock in-out";
$lang["custom_widget_details"] = "Custom widget details";

$lang["total_projects"] = "Total projects";
$lang["total_invoices"] = "Total invoices";
$lang["total_payments"] = "Total payments";
$lang["total_due"] = "Total due";

$lang["show_title"] = "Show title";
$lang["show_border"] = "Show border";

$lang["all_tasks_kanban"] = "All tasks kanban";
$lang["todo_list"] = "Todo list";
$lang["open_projects_list"] = "Open Projects List";
$lang["starred_projects"] = "Starred Projects";
$lang["completed_projects"] = "Completed Projects";

$lang["new_tickets"] = "New Tickets";
$lang["closed_tickets"] = "Closed Tickets";

$lang["clocked_in_team_members"] = "Clocked in team members";
$lang["clocked_out_team_members"] = "Clocked out team members";
$lang["latest_online_client_contacts"] = "Latest online client contacts";
$lang["latest_online_team_members"] = "Latest online team members";
$lang["my_tasks_list"] = "My tasks list";

$lang["discount"] = "Discount";
$lang["discount_type"] = "Discount Type";
$lang["edit_discount"] = "Edit discount";
$lang["discount_amount"] = "Discount amount";
$lang["fixed_amount"] = "Fixed Amount";
$lang["before_tax"] = "Before Tax";
$lang["after_tax"] = "After Tax";

$lang["access_permission"] = "Access Permission";
$lang["setup"] = "Setup";
$lang["client_permissions"] = "Client permissions";

$lang["invoice_over_payment_error_message"] = "You can't pay more than your invoice due.";
$lang["account_already_exists_for_your_company_name"] = "Account already exists for your company name.";
$lang["personal_language"] = "Personal language";
$lang["no_messages_text"] = "You don't have any messages yet";
$lang["no_users_found"] = "No users found";

$lang["create_project"] = "Create project";

/* Version 2.2 */

$lang["imap_settings"] = "IMAP settings";
$lang["enable_email_piping"] = "Enable Email piping";
$lang["imap_host"] = "IMAP Host";
$lang["imap_port"] = "Port";
$lang["imap_ssl_enabled"] = "SSL Enabled";
$lang["please_upgrade_your_php_version"] = "Please upgrade your PHP Version for this operation.";
$lang["required_version"] = "Required Version";
$lang["email_piping_help_message"] = "Please make sure that, your IMap access is enabled.";

$lang["enable_rich_text_editor"] = "Enable rich text editor in comments/description";

$lang["show_assigned_tasks_only"] = "Show assigned tasks only";

$lang["batch_update"] = "Batch update";
$lang["cancel_selection"] = "Cancel selection";
$lang["select_status"] = "Select status";

$lang["add_multiple_tasks"] = "Add multiple tasks";
$lang["save_and_add_more"] = "Save & add more";
$lang["add_project_time"] = "Add project time";
$lang["add_to_do"] = "Add to do";
$lang["hide_menus_from_topbar"] = "Hide menus from topbar";
$lang["favorite_projects"] = "Favorite projects";
$lang["favorite_clients"] = "Favorite clients";
$lang["dashboard_customization"] = "Dashboard customization";
$lang["quick_add"] = "Quick add";

$lang["assign_to_me"] = "Assign to me";

$lang["favicon"] = "Favicon";

$lang["enable_google_drive_api_to_upload_file"] = "Enable Google Drive API to upload file";
$lang["drive_activation_help_message"] = "From now on, all files will be uploaded into Google Drive.";

$lang["mark_all_as_read"] = "Mark all as read";
$lang["marked_all_notifications_as_read"] = "Marked all notifications as read";

$lang["project_completed"] = "Project completed";
$lang["notification_project_completed"] = "Completed a project";

$lang["google_drive_client_id"] = "Client ID";
$lang["google_drive_client_secret"] = "Client secret";
$lang["get_your_app_credentials_from_here"] = "Get your app credentials from here:";
$lang["remember_to_add_this_url_in_authorized_redirect_uri"] = "Remember to add this url in Authorized redirect uri";
$lang["save_and_authorize"] = "Save & authorize";

$lang["preview_next_key"] = "Next (Right arrow key)";
$lang["preview_previous_key"] = "Previous (Left arrow key)";

$lang["filters"] = "Filters";

$lang["authorized"] = "Authorized";
$lang["unauthorized"] = "Unauthorized";

$lang["not_clocked_id_yet"] = "Not clocked in yet";

$lang["create_estimate_request"] = "Create estimate request";

$lang["in_last_number_of_days"] = "In last %s days";
$lang["in_last_number_of_month"] = "In last %s month";
$lang["in_last_number_of_months"] = "In last %s months";

$lang["pusher_app_id"] = "App ID";
$lang["pusher_key"] = "Key";
$lang["pusher_secret"] = "Secret";
$lang["pusher_cluster"] = "Cluster";
$lang["enable_push_notification"] = "Enable push notification";
$lang["push_notification"] = "Push notification";
$lang["disable_push_notification"] = "Disable push notification";

$lang["unknown_client"] = "Unknown client";

$lang["income_expenses_widget_help_message"] = "This report is only usable if you are using single currency.";

$lang["assign_myself_in_this_ticket"] = "Assign myself in this ticket";

$lang["create_new_task"] = "Create new task";

$lang["default_due_date_after_billing_date"] = "Default due date after billing date";

$lang["field_type_external_link"] = "External link";

$lang["total_days"] = "Total days";

$lang["my_timesheet"] = "My timesheet";
$lang["all_timesheets"] = "All timesheets";
$lang["my_timesheet_statistics"] = "My timesheet statistics";
$lang["all_timesheets_statistics"] = "All timesheets statistics";

$lang["no_field_has_selected"] = "No field has selected!";

$lang["imap_help_message_1"] = "You can setup an email address to create the tickets automatically when you receive any emails at that address.";
$lang["imap_help_message_2"] = "Please note that, the system will create tickets based on the unread emails. After creating the ticket, the emails will be marked as read. To get the replies in the same tickets, the system will check the ticket ID in the email subject. If there is no ticket ID in the subject, that will be considered as a new ticket. You can setup the email subject from the";
$lang["imap_error_credentials_message"] = "Error! Can't connect with the imap using the credentials.";

$lang["client_message_own_contacts"] = "Client can send/receive message to/from own contacts?";

$lang["print_invoice"] = "Print invoice";

$lang["mark_invoice_as_cancelled"] = "Mark as cancelled";
$lang["cancelled"] = "Cancelled";
$lang["cancelled_at"] = "Cancelled at";
$lang["cancelled_by"] = "Cancelled by";

/* Version 2.3 */

$lang["test_push_notification"] = "Test push notification";
$lang["notification_test_push_notification"] = "It's a demo push notification";
$lang["push_notification_error_message"] = "Error! Can't connect with the Pusher using the credentials.";
$lang["clone_estimate"] = "Clone Estimate";

$lang["import_clients"] = "Import clients";
$lang["download_sample_file"] = "Download sample file";

$lang["estimate_settings"] = "Estimate Settings";
$lang["estimate_logo"] = "Estimate Logo";
$lang["estimate_color"] = "Estimate Color";
$lang["initial_number_of_the_estimate"] = "Initial number of the estimate";
$lang["the_estimates_id_must_be_larger_then_last_estimate_id"] = "The estimates ID must be larger then last estimate ID.";

$lang["send_to_client"] = "Send to client";
$lang["estimate_sent_message"] = "The estimate has been sent!";
$lang["send_estimate_bcc_to"] = "When sending estimate to client, send BCC to";
        
$lang["task_settings"] = "Task settings";
$lang["enable_recurring_option_for_tasks"] = "Enable recurring option for tasks";
$lang["past_recurring_date_error_message_title_for_tasks"] = "The selected start date and repeat type returns a past date.";
$lang["recurring_task_created_via_cron_job"] = "Recurring task created via Cron Job";
$lang["notification_recurring_task_created_via_cron_job"] = "New task created";
$lang["repeat_type"] = "Repeat type";
$lang["lead_status"] = "Lead status";
$lang["add_lead_status"] = "Add lead status";
$lang["edit_lead_status"] = "Edit lead status";
$lang["delete_lead_status"] = "Delete lead status";
$lang["owner"] = "Owner";
$lang["make_client"] = "Make client";
$lang["client_contacts"] = "Client contacts";
$lang["lead_contacts"] = "Lead contacts";
$lang["add_a_lead"] = "Add a lead";
$lang["source"] = "Source";
$lang["lead_source"] = "Lead source";
$lang["add_lead_source"] = "Add lead source";
$lang["edit_lead_source"] = "Edit lead source";
$lang["delete_lead_source"] = "Delete lead source";
$lang["custom_field_migration"] = "Custom field migration";
$lang["merge_custom_fields"] = "Merge custom fields";
$lang["do_not_merge"] = "Do not merge";
$lang["merge_custom_fields_help_message"] = "If there is any similar custom fields exists for %s, this values will be added to those. Otherwise, this will create new custom fields for %s and add values to those.";
$lang["lead_created"] = "Lead created";
$lang["notification_lead_created"] = "Created a new lead.";
$lang["client_created_from_lead"] = "Client created from lead";
$lang["notification_client_created_from_lead"] = "Converted a lead to client.";
$lang["project_deadline"] = "Project deadline";
$lang["task_deadline"] = "Task deadline";
$lang["event_type"] = "Event type";
$lang["delete_estimate_form"] = "Delete estimate form";
$lang["calendar_event_modified"] = "Calendar event modified";
$lang["notification_calendar_event_modified"] = "Modified an event.";

$lang["there_has_leads_with_this_status"] = "There has leads with this status";
$lang["lead_created_at"] = "Lead created at";
$lang["past_lead_information"] = "Past lead information";
$lang["last_status"] = "Last status";
$lang["migrated_to_client_at"] = "Migrated to client at";
$lang["edit_estimate_form"] = "Edit estimate form";

$lang["please_upload_a_excel_file"] = "Please upload a excel file.";
$lang["back"] = "Back";

$lang["import_client_error_header"] = "There has an invalid header. The indicated field should be <b>%s</b>.";
$lang["import_client_error_company_name_field_required"] = "Company name field is required.";
$lang["import_client_error_contact_name"] = "Contact first name and last is both required to add a client contact.";
$lang["import_client_error_contact_email"] = "Contact email is required and should be unique to add a client contact.";
$lang["error"] = "Error";
$lang["contact_first_name"] = "Contact first name";
$lang["contact_last_name"] = "Contact last name";
$lang["contact_email"] = "Contact email";

$lang["clone_invoice"] = "Clone Invoice";
$lang["copy_items"] = "Copy items";
$lang["copy_discount"] = "Copy discount";

$lang["clone_task"] = "Clone task";
$lang["copy_checklist"] = "Copy checklist";

$lang["auto_assign_estimate_request_to"] = "Auto assign estimate request to";

$lang["email_template_variable"] = "Email template variable";
$lang["example_variable_name"] = "Example_variable_name";

$lang["imap_extension_error_help_message"] = "You don't have IMAP extension in your server. Please install the extension for this action.";

$lang["initial_number_of_the_invoice"] = "Initial number of the invoice";
$lang["the_invoices_id_must_be_larger_then_last_invoice_id"] = "The invoices ID must be larger then last invoice ID.";

$lang["client_dashboard_help_message"] = "This will be the default dashboard for all clients. Please note that, the information you're seeing here in the widgets, isn't any actual infromation of clients.";

$lang["send_to_lead"] = "Send to lead";
$lang["lead"] = "Lead";
$lang["leads"] = "Leads";
$lang["add_lead"] = "Add lead";
$lang["edit_lead"] = "Edit lead";
$lang["delete_lead"] = "Delete lead";
$lang["lead_details"] = "Lead details";
$lang["can_access_leads_information"] = "Can access lead's information?";
$lang["lead_info"] = "Lead info";

$lang["send_task_reminder_on_the_day_of_deadline"] = "Send task reminder on the day of deadline";
$lang["send_task_deadline_pre_reminder"] = "Send task deadline pre reminder";
$lang["send_task_deadline_overdue_reminder"] = "Send task deadline overdue reminder";

$lang["project_task_deadline_reminder"] = "Project task deadline reminder";

$lang["project_task_deadline_pre_reminder"] = "Project task deadline pre reminder";
$lang["project_task_deadline_overdue_reminder"] = "Project task deadline overdue reminder";
$lang["project_task_reminder_on_the_day_of_deadline"] = "Project task reminder on the day of deadline";

$lang["notification_project_task_deadline_pre_reminder"] = "Reminder: Some tasks needs to be finished soon.";
$lang["notification_project_task_deadline_overdue_reminder"] = "Reminder: Task's deadline overdue.";
$lang["notification_project_task_reminder_on_the_day_of_deadline"] = "Reminder: Some tasks needs to be finished today.";

$lang["mark_as_public"] = "Mark as public";
$lang["note_details"] = "Note details";
$lang["public_note_by"] = "Public note by";
$lang["marked_as_public"] = "Marked as public";

$lang["client_can_view_activity"] = "Client can view project activity";

$lang["event_settings"] = "Event settings";
$lang["enable_google_calendar_api"] = "Enable Google calendar API";
$lang["google_calendar_settings"] = "Google calendar settings";

$lang["your_calendar_ids"] = "Your Calendar IDs";
$lang["calendar_id"] = "Calendar ID";
$lang["now_every_user_can_integrate_with_their_google_calendar"] = "Now every user can integrate with their Google calendar.";
$lang["calendar_ids_help_message"] = "You'll get your own calendar events always. This is for other special calendars (Like Holidays Calendar).";

$lang["google_client_id"] = "Client ID";
$lang["google_client_secret"] = "Client secret";
$lang["integrate_with_google_calendar"] = "Integrate with Google calendar";
$lang["google_calendar_event"] = "Google Calendar event";

$lang["mark_as_public_help_message"] = "You can't make this note as private again.";

$lang["google_calendar_help_message"] = "You'll get your Google Calendar events by the run of Cron job. And any add/modification of your local events will effect your Google calendar instantly.";